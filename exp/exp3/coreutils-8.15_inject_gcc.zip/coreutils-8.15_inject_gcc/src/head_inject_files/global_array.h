#ifndef GLOBAL_ARRAY_H
#define GLOBAL_ARRAY_H
extern void addToArray(void** p,unsigned int id) ;
extern void freeArray() ;
extern void crest_use() ;
#endif
